#include"Winuser.h"
#include <commctrl.h>     
#pragma comment(lib,"ComCtl32.lib")

class ShowBmpEx
{
public:
	HBITMAP GetBmp(int ID,int a,int b,int c,int d)
	{
      static HDC hScrDC,hMemDC;   
      int RectWidth,RectHeight;
      HBITMAP  hBitmap,hOldBitmap,hOld2;    
      HBITMAP SrcBitmap;
      hMemDC=CreateCompatibleDC(NULL);  
      RectWidth=c; 
      RectHeight=d;
      SrcBitmap= LoadBitmap (GetModuleHandle(NULL) ,MAKEINTRESOURCE(ID)) ;
      hScrDC=CreateCompatibleDC(NULL);  
      hOld2=(HBITMAP)SelectObject(hScrDC,SrcBitmap);  

      hBitmap=CreateCompatibleBitmap(hScrDC,RectWidth,RectHeight);   
      hOldBitmap=(HBITMAP)SelectObject(hMemDC,hBitmap);    
      BitBlt(hMemDC,0,0,RectWidth,RectHeight,hScrDC,a,b,SRCCOPY);   
      hBitmap=(HBITMAP)SelectObject(hMemDC,hOldBitmap);  

	  SelectObject(hScrDC,hOld2);
      if(DeleteObject(SrcBitmap)==NULL)MessageBox(0,"ɾ��λͼ����ʧ��","λ�ã�GetBmp",0);
      if(DeleteDC(hScrDC)==NULL)MessageBox(0,"ɾ��DCʧ��","λ�ã�GetBmp hSrcDC",0); 
      if(DeleteDC(hMemDC)==NULL)MessageBox(0,"ɾ��DCʧ��","λ�ã�GetBmp hMemDC",0);   
      return hBitmap; 
	}
	//������ɫ
     void TransBmp(HDC hDc,long ID,int X,int Y,int weidth,int hight,COLORREF color,int xs,int ys)
	 {
      HBITMAP           hBitmap,hOld=NULL;
	  HDC               hMaskDc;
	  BITMAP            Bmp;
	  hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));
      GetObject(hBitmap,sizeof(BITMAP),(LPSTR)&Bmp);
      hMaskDc=CreateCompatibleDC(hDc);
      hOld=(HBITMAP)SelectObject(hMaskDc,hBitmap);
	  hight?1:hight=Bmp.bmHeight-ys;
	  weidth?1:weidth=Bmp.bmWidth-xs;
	  if(color==-2)     BitBlt(hDc,X,Y,weidth,hight,hMaskDc,xs,ys,SRCCOPY);
	  else              TransparentBlt(hDc, X, Y,weidth,hight,hMaskDc,xs,ys,weidth,hight,color);	
	  SelectObject(hMaskDc,hOld);
      if(DeleteObject(hBitmap)==0)MessageBox(0,"ɾ������ʧ��","",0);
      DeleteDC(hMaskDc);
	 }
	 //͸����ʾ
	 void AlphaBmp(HDC hdc,long ID,int x,int y,int weidth,int hight,short limit,int xs,int ys)
	 {
        BLENDFUNCTION blendfunc;
		HDC hMaskDc;
		HBITMAP hBitmap,hOld=NULL;
		BITMAP Bmp;
		blendfunc.BlendFlags=0;
	 	blendfunc.AlphaFormat=0;
		blendfunc.SourceConstantAlpha=(unsigned char)limit; 
		blendfunc.BlendOp=AC_SRC_OVER;
		hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));
		GetObject(hBitmap,sizeof(BITMAP),(LPSTR)&Bmp);
	    hight?1:hight=Bmp.bmHeight-ys;
	    weidth?1:weidth=Bmp.bmWidth-xs;
		hMaskDc=CreateCompatibleDC(hdc);
		hOld=(HBITMAP)SelectObject(hMaskDc,hBitmap);
        AlphaBlend(hdc,x,y,weidth,hight,hMaskDc,xs,ys,weidth,hight,blendfunc);
		SelectObject(hMaskDc,hOld);
		if(DeleteObject(hBitmap)==0)MessageBox(0,"�¼���ɾ������(hbitmap)ʧ��\nλ�ã�AlphaBmp","",0);
        DeleteDC(hMaskDc);
	 }
	 //������ʾ
	 void StretchBmp(HDC hdc,long ID,int x,int y,int weidth,int hight,int xs,int ys,int sweidth,int shight)
	 {
      HBITMAP           hBitmap,hOld=NULL;
	  HDC               hMaskDc;
	  BITMAP            Bmp;
	  hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));
      GetObject(hBitmap,sizeof(BITMAP),(LPSTR)&Bmp);
      hMaskDc=CreateCompatibleDC(hdc);
      hOld=(HBITMAP)SelectObject(hMaskDc,hBitmap);
	  hight?1:hight=Bmp.bmHeight;
	  weidth?1:weidth=Bmp.bmWidth;
	  shight?1:shight=Bmp.bmHeight-ys;
	  sweidth?1:sweidth=Bmp.bmWidth-xs;
	  StretchBlt(hdc,x, y,weidth,hight,hMaskDc,xs,ys,sweidth,shight,SRCCOPY);
	  SelectObject(hMaskDc,hOld);
      if(DeleteObject(hBitmap)==0)MessageBox(0,"ɾ������ʧ��","",0);
      DeleteDC(hMaskDc);
	 }
};