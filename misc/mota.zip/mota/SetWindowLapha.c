class SetWindowLapha
{
public:
 void Set(HWND hwnd, short depth)
 {
   LONG lWindowLong = GetWindowLong(hwnd, GWL_EXSTYLE) |0x00080000;
   SetWindowLong(hwnd, GWL_EXSTYLE, lWindowLong);
   SetLayeredWindowAttributes(hwnd, 0,(unsigned char)depth,2);
 }
typedef BOOL (FAR WINAPI *LAYERFUNC)(HWND,COLORREF,BYTE,DWORD); 
BOOL SetLayeredWindowAttributes(HWND hwnd,COLORREF crKey,BYTE bAlpha,DWORD dwFlags)
{
LAYERFUNC SetLayer;
HMODULE hmod = LoadLibrary("user32.dll");
SetLayer=(LAYERFUNC)GetProcAddress(hmod,"SetLayeredWindowAttributes");
BOOL bReturn = SetLayer(hwnd,crKey,bAlpha,dwFlags);
FreeLibrary(hmod);
return bReturn;
}
};