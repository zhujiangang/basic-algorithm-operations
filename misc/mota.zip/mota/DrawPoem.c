void DrawPoem(HDC hDc,int X,int Y,LPSTR str,char FontName[25],int wi,int hi,int we,int vg,int hg)       
{
  HFONT hFont;
  int i,l;
  LOGFONT LogFont ={   0   };   
  LogFont.lfCharSet =GB2312_CHARSET;   
  LogFont.lfClipPrecision =0;   
  LogFont.lfEscapement =0;   
  strcpy(LogFont.lfFaceName,FontName);
  LogFont.lfHeight =hi;          
  LogFont.lfItalic=0;   
  LogFont.lfOrientation=0;   
  LogFont.lfOutPrecision = 0;   
  LogFont.lfPitchAndFamily =0;   
  LogFont.lfQuality  =0;   
  LogFont.lfStrikeOut = 0;   
  LogFont.lfUnderline  = 0;   
  LogFont.lfWeight =we;   
  LogFont.lfWidth=wi;  
  hFont=CreateFontIndirect (&LogFont);
  SelectObject (hDc,hFont);
  l=lstrlen(str)/2;
  for(i=0;i<l;i++)
  {
	  if(*str=='\n'){l-=i;;X-=(wi+hg);i=0;str++;}
       TextOut (hDc,X, Y+i*(hi+vg), str, 2) ;
       str+=2; 
  }
  if(DeleteObject(hFont)==NULL)MessageBox(0,"ɾ������ʧ��","",0);
}