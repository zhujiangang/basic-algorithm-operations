class   CMusic 
{
public:
DWORD   Play(HWND,char*FileName); 
void   Replay();
void   Stop();
private:
UINT   wDeviceID;
DWORD   dwReturn;
MCI_OPEN_PARMS   mciOpenParms; 
MCI_PLAY_PARMS   mciPlayParms;
MCI_STATUS_PARMS   mciStatusParms;
MCI_SEQ_SET_PARMS   mciSeqSetParms;
};

DWORD   CMusic::Play(HWND   hwnd,char*  File)   
{
    mciOpenParms.lpstrDeviceType   ="mpegvideo"; 
    mciOpenParms.lpstrElementName   =  File; 
	wDeviceID=0;
    if(dwReturn = mciSendCommand(NULL, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_ELEMENT, (DWORD)(LPVOID) &mciOpenParms))
	{
		MessageBox(0,"","",0);
    return (dwReturn); 
	}
    wDeviceID = mciOpenParms.wDeviceID; 
    mciStatusParms.dwItem =   MCI_SEQ_STATUS_PORT; 
    if(dwReturn = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM, (DWORD)(LPVOID) &mciStatusParms)) 
    {
       mciSendCommand(wDeviceID, MCI_CLOSE, 0, NULL); 
       return   (dwReturn);
	} 
    mciPlayParms.dwCallback = (DWORD) hwnd; 
    if (dwReturn = mciSendCommand(wDeviceID, MCI_PLAY, MCI_NOTIFY, (DWORD)(LPVOID) &mciPlayParms)) 
	{ 
     mciSendCommand(wDeviceID, MCI_CLOSE, 0, NULL);
     return   (dwReturn); 
	}
return   (0L);
};   
void CMusic::Replay()
{
mciSendCommand(wDeviceID, MCI_SEEK,MCI_SEEK_TO_START, NULL);
mciSendCommand(wDeviceID, MCI_PLAY, MCI_NOTIFY, (DWORD)(LPVOID) &mciPlayParms);
}
void CMusic::Stop()
{
mciSendCommand(wDeviceID,   MCI_CLOSE,   0,   NULL);
}