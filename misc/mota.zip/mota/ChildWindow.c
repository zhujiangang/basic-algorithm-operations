class ChildWindow
{
public:
   HWND hwnd;
   HWND hParent;
   LPSTR Class;
   HINSTANCE hInstance;
   HCURSOR hCur;
   HBRUSH hBrush;
   WNDPROC WndProc;
   LPSTR Caption;
   LPSTR szWindowName;
   void Create(DWORD,DWORD,int,int,int,int);
private:
	 int regist();
};

void ChildWindow::Create(DWORD dwExStyle,DWORD dwStyle,int x,int y,int nWidth,int nHeight)
{
 
  if(!hwnd)regist();
  hwnd=CreateWindowEx(dwExStyle,Class,Caption,dwStyle,x,y,nWidth,nHeight,hParent,NULL,GetModuleHandle(0), NULL); 
  if(hwnd==0)MessageBox(0,"��������ʧ��","",0);
  //ShowWindow(hwnd,0);
  UpdateWindow(hwnd);
}
int  ChildWindow::regist()
{
   WNDCLASSEX WndClass;
   if(hCur==NULL)hCur=LoadCursor(NULL, IDC_ARROW);
   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = (WNDPROC)WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = hInstance;
   WndClass.hIcon         = NULL;
   WndClass.hCursor       = hCur;
   WndClass.hbrBackground = hBrush;
   WndClass.lpszMenuName  = 0;
   WndClass.lpszClassName = Class;
   WndClass.hIconSm       = 0;
    if(!RegisterClassEx(&WndClass))
	{
      MessageBox(0, "ע�ᴰ��ʧ��", "������Ϣ",MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
    }
  return 1;
 }