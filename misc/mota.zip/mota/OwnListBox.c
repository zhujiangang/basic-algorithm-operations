class OwnListBox
{
public:
typedef unsigned char PtrData[9];
    void ShowBitmap(HDC hDc,int x,int y,COLORREF color,long ID)
	{
      HBITMAP hBitmap,hOld=NULL;
	  HDC hMaskDc;
	  BITMAP Bmp;
      hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));	  
	  if(hBitmap){
      GetObject(hBitmap,sizeof(BITMAP),(LPSTR)&Bmp);
      hMaskDc=CreateCompatibleDC(hDc);
      hOld=(HBITMAP)SelectObject(hMaskDc,hBitmap);
	  if(color==-2)BitBlt(hDc,x,y,Bmp.bmWidth,Bmp.bmHeight,hMaskDc,0,0,SRCCOPY);
	  else  TransparentBlt(hDc,x,y,Bmp.bmWidth,Bmp.bmHeight,hMaskDc,0,0,Bmp.bmWidth,Bmp.bmHeight,color);	
	  SelectObject(hMaskDc,hOld);
      if(DeleteObject(hBitmap)==0)MessageBox(0,"ɾ��ʧ��","21321",0);
      DeleteDC(hMaskDc);
	  }
	}
	
protected:
    virtual LRESULT Proc(HWND,UINT,WPARAM,LPARAM);
	PtrData m_PtrData;
    
	void inline PtrInit(PtrData t,void *This)
	{
	t[0]=0xB9;
	*((DWORD *)(t+1))=(DWORD)This;
    *((DWORD *)(t+5))=0x20FF018B;
	}
public:
    HWND hParent;
	HWND hwnd;
	HCURSOR hCur;
	RECT RBn1;
 	long ID;
	long IDNormal;
	long IDHover;
	long IDPushed;
    HBITMAP hBkbmp;
private:
	WNDPROC OldProc;
	BOOL Draw;
	int i;
	HBRUSH br;
public:
	#if((_WIN32_WINNT   >=   0x0400)   ||   (WINVER   >=   0x0500))   
    #define   WM_MOUSEHOVER                                       0x02A1   
    #define   WM_MOUSELEAVE                                       0x02A3  
    #endif
    BOOL Create(DWORD dwStyle,int x,int y,int weidth,int height)
	{
	  PtrInit(m_PtrData,this);
	  hwnd=CreateWindowEx(WS_EX_TOPMOST,"listbox","",dwStyle ,x,y,weidth,height, hParent,(HMENU)ID,GetModuleHandle(0),0);
      OldProc=(WNDPROC)::SetWindowLong(hwnd,GWL_WNDPROC,(LONG)(void*)m_PtrData);
	  if(hCur)SetClassLong(hwnd,GCL_HCURSOR,(long)hCur);
	 SetWindowPos(hwnd,HWND_TOPMOST,x,y,weidth,height,SWP_FRAMECHANGED);
	  Draw=true;
	  
	  br=CreatePatternBrush(hBkbmp);
	  return 1;
	}
};

LRESULT OwnListBox::Proc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
	{ 
     switch(uMsg) { 
            case WM_ERASEBKGND:
			RECT rc;
			GetClientRect(hwnd,&rc);
			FillRect((HDC)wParam,&rc,br);
			return TRUE;
			break;
		case WM_KEYUP:
        if(wParam==32)
		{
			if(LOWORD(SendMessage(hwnd,LB_ITEMFROMPOINT,0,lParam))!=LB_ERR)
			 SendMessage(hParent,WM_COMMAND,MAKEWPARAM(0,LBN_DBLCLK),(LPARAM)hwnd);
		}
		else //��������Ϣ���͸�������
		{
		 SendMessage(hParent,WM_KEYUP,wParam,0);
		}
		case WM_KEYDOWN:
         SendMessage(hParent,WM_KEYDOWN,wParam,0);
        return CallWindowProc(OldProc,hwnd,uMsg,wParam,lParam);  
		break;
		break;
		case  WM_LBUTTONDBLCLK:
			 if(LOWORD(SendMessage(hwnd,LB_ITEMFROMPOINT,0,lParam))!=LB_ERR)
			 SendMessage(hParent,WM_COMMAND,MAKEWPARAM(0,LBN_DBLCLK),(LPARAM)hwnd);
			 //MessageBox(0,"","",0);
             return CallWindowProc(OldProc,hwnd,uMsg,wParam,lParam);  
        break; 
        default: 
		return CallWindowProc(OldProc,hwnd,uMsg,wParam,lParam);  
        break; 
	 }
 return 1;
}
