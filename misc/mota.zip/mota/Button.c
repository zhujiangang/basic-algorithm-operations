#include"Winuser.h"
#include <commctrl.h>     
#pragma comment(lib,"ComCtl32.lib")
class DRAWBUTTON
{
public:
typedef unsigned char PtrData[9];
protected:
    virtual LRESULT BnProc(HWND hBnClose,UINT uMsgBn,WPARAM wParam,LPARAM lParam);
	PtrData m_PtrData;
	BOOL CreateToolTip(HWND hwndTool, TCHAR* pText)   
	{    
    static HWND hwndTip ;
    HINSTANCE g_hInst = GetModuleHandle(NULL);   
    #ifndef TTS_BALLOON   
    #define TTS_BALLOON 0x40   
    #endif  
     TOOLINFO toolInfo = { 0 }; 
	 if(hwndTip==NULL)
     hwndTip = CreateWindowEx(NULL, TOOLTIPS_CLASS, NULL,   
                //WS_POPUP |TTS_ALWAYSTIP | TTS_BALLOON,//������   
               WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP,//��ͨ������   
                CW_USEDEFAULT, CW_USEDEFAULT,   
                CW_USEDEFAULT, CW_USEDEFAULT,   
                GetParent(hwndTool), NULL,    
               g_hInst, NULL);   
    if (!hwndTool || !hwndTip)   
    {   
        return FALSE;   
    }      
    toolInfo.cbSize = sizeof(toolInfo);   
    toolInfo.hwnd = hwndTool;   
    toolInfo.uFlags = TTF_IDISHWND | TTF_SUBCLASS;   
    toolInfo.uId = (UINT_PTR)hwndTool;   
    toolInfo.lpszText = pText;   
    SendMessage(hwndTip, TTM_ADDTOOL, 0, (LPARAM)&toolInfo);   
    return TRUE;   
	}  
    void ShowBitmap(HDC hDc,COLORREF color,long ID)
	{
      HBITMAP hBitmap,hOld=NULL;
	  HDC hMaskDc;
	  BITMAP Bmp;
      hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));	  
	  if(hBitmap){
      GetObject(hBitmap,sizeof(BITMAP),(LPSTR)&Bmp);
      hMaskDc=CreateCompatibleDC(hDc);
      hOld=(HBITMAP)SelectObject(hMaskDc,hBitmap);
	  if(color==-2)BitBlt(hDc,0,0,Bmp.bmWidth,Bmp.bmHeight,hMaskDc,0,0,SRCCOPY);
	  else  TransparentBlt(hDc,0,0,Bmp.bmWidth,Bmp.bmHeight,hMaskDc,0,0,Bmp.bmWidth,Bmp.bmHeight,color);	
	  SelectObject(hMaskDc,hOld);
      if(DeleteObject(hBitmap)==0)MessageBox(0,"ɾ��ʧ��DrawButton","",0);
      DeleteDC(hMaskDc);
	  }
	}
	void inline PtrInit(PtrData t,void *This)
	{
	t[0]=0xB9;
	*((DWORD *)(t+1))=(DWORD)This;
    *((DWORD *)(t+5))=0x20FF018B;
	}
public:
	long IDNormal;
	long IDPush;
	long IDHover;
	long ButtonID;
	COLORREF CNormal;
	COLORREF CHover;
	COLORREF CPush;
	COLORREF TextCol;
	LPSTR ToolTipsText;
	char lpWindowName[40];
	HRGN rBn;
	HWND hParent;
	HWND hButton;
	HCURSOR hCur;
	HFONT hFont;
	HPEN hPen;
private:
	WNDPROC OldProc;
	long IDPAINT;
	COLORREF CPaint;
	HDC hDc;
	BOOL times;
	RECT rc;
    BOOL Draw;
	BOOL focus;
public:
	#if((_WIN32_WINNT   >=   0x0400)   ||   (WINVER   >=   0x0500))   
    #define   WM_MOUSEHOVER                                       0x02A1   
    #define   WM_MOUSELEAVE                                       0x02A3  
    #endif
    BOOL DrawButton(DWORD dwStyle,int x,int y,int nWidth,int nHeight,HINSTANCE hlnstance)
	{
	  PtrInit(m_PtrData,this);
      IDPAINT=IDNormal;
	  CPaint=CNormal;
	  times=0;
      hButton=CreateWindow("button","",dwStyle,x,y,nWidth,nHeight,hParent,(HMENU)ButtonID,0,0);
      OldProc=(WNDPROC)::SetWindowLong(hButton,GWL_WNDPROC,(LONG)(void*)m_PtrData);
	  if(hCur)SetClassLong(hButton,GCL_HCURSOR,(long)hCur);
	  if(rBn!=NULL)SetWindowRgn(hButton,rBn,TRUE);
	  GetClientRect(hButton,&rc);
	  Draw=0;
	  focus=0;
	  return 1;
	}
	HRGN BitmapToRgn(long ID,COLORREF col)
	{
	HDC hMemDc;
	HBITMAP hBitmap,hOld;
	COLORREF CPixel;
	HRGN rTemp,hGoal;
	BITMAP Bmp;
	hBitmap=LoadBitmap(GetModuleHandle(0),MAKEINTRESOURCE(ID));
    GetObject(hBitmap,sizeof(BITMAP),&Bmp);
	hMemDc=CreateCompatibleDC(NULL);
	hOld=(HBITMAP)SelectObject(hMemDc,hBitmap);
	hGoal=CreateRectRgn(0,0,Bmp.bmWidth,Bmp.bmHeight);
	for(int x=0;x<=Bmp.bmWidth;x++)
		for(int y=0;y<=Bmp.bmHeight;y++)
		{
          CPixel=GetPixel(hMemDc,x,y);
			  if(CPixel==col)
			  {
                rTemp=CreateRectRgn(x,y,x+1,y+1);
				CombineRgn(hGoal,hGoal,rTemp,RGN_XOR);
				DeleteObject(rTemp);
			  }
		}
   SelectObject(hMemDc,hOld);
   if(DeleteObject(hBitmap)==NULL)MessageBox(0,"�¼���ɾ����ͼ����ʧ��\nλ�ã�BitmapToRgn()����","",0);
   DeleteDC(hMemDc);
   return hGoal;
	}

   HFONT CreateFont(char FontName[25],int wi,int hi,int we)
   {
     LOGFONT LogFont ={   0   };   
     LogFont.lfCharSet =GB2312_CHARSET;   
     LogFont.lfClipPrecision =0;   
     LogFont.lfEscapement =0;   
     strcpy(LogFont.lfFaceName,FontName);
     LogFont.lfHeight =hi;          
     LogFont.lfItalic=0;   
     LogFont.lfOrientation=0;   
     LogFont.lfOutPrecision = 0;   
     LogFont.lfPitchAndFamily =0;   
     LogFont.lfQuality  =0;   
     LogFont.lfStrikeOut = 0;   
     LogFont.lfUnderline  = 0;   
     LogFont.lfWeight =we;   
     LogFont.lfWidth=wi;  
     return CreateFontIndirect (&LogFont);
   }
      

};

LRESULT DRAWBUTTON::BnProc(HWND hBn,UINT uMsgBn,WPARAM wParam,LPARAM lParam)
	{ 
	 static HDC hPaintDC;
	 static PAINTSTRUCT ps;
	 HDC hDc=GetDC(hBn);
     switch(uMsgBn) {  
       case WM_MOUSELEAVE:
		Draw=0;
		ShowBitmap(hDc,CNormal,IDNormal); 
        if(strlen(lpWindowName)){
        if(hFont)SelectObject(hDc,hFont);
		SetTextColor(hDc,TextCol);
		SetBkMode(hDc,TRANSPARENT);
		DrawText(hDc,lpWindowName,strlen(lpWindowName),&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
		}
		
		IDPAINT=IDNormal;
		CPaint=CNormal;
		times=0;
	    break; 
	   case WM_PAINT:
		Draw=0;
		hPaintDC=BeginPaint(hBn,&ps);
        ShowBitmap(hPaintDC,CPaint,IDPAINT);
		if(strlen(lpWindowName)){
        if(hFont)SelectObject(hPaintDC,hFont);
		SetTextColor(hPaintDC,TextCol);
		SetBkMode(hPaintDC,TRANSPARENT);
		DrawText(hPaintDC,lpWindowName,strlen(lpWindowName),&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
		}
        SendMessage(hParent,WM_COMMAND,MAKEWPARAM(0,BN_PAINT),(LPARAM)hBn);
        
		EndPaint(hBn,&ps);
		break;
	   case WM_MOUSEHOVER:
		Draw=0;
     	CreateToolTip(hBn,ToolTipsText);
       	SendMessage(hParent,WM_COMMAND,MAKEWPARAM(0,BN_UNPUSHED),(LPARAM)hBn);
	    break;
	   case WM_LBUTTONDOWN:
		Draw=0;
		SendMessage(hParent,WM_COMMAND,MAKEWPARAM(0,BN_PUSHED),(LPARAM)hBn);
        ShowBitmap(hDc,CPush,IDPush); 
		if(strlen(lpWindowName)){
        if(hFont)SelectObject(hDc,hFont);
		SetTextColor(hDc,TextCol);
		SetBkMode(hDc,TRANSPARENT);
		DrawText(hDc,lpWindowName,strlen(lpWindowName),&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
		}
		IDPAINT=IDPush;
		CPaint=CPush;
		times=1;
		 SetFocus(hButton);
		break;
	   case WM_SETFOCUS:
          focus=true;
		   break;
	   case WM_KILLFOCUS:
		  // MessageBox(0,"","",0);
		   focus=false;
		   InvalidateRect(hBn,0,1);
		   break;
	   case WM_LBUTTONUP:
		SetFocus(hButton);
		Draw=0;
		ShowBitmap(hDc,CHover,IDHover);
		if(strlen(lpWindowName)){
        if(hFont)SelectObject(hDc,hFont);
		SetTextColor(hDc,TextCol);
		SetBkMode(hDc,TRANSPARENT);
		DrawText(hDc,lpWindowName,strlen(lpWindowName),&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
		}
		IDPAINT=IDHover;
		CPaint=CHover;
		if(times)
		{
		SendMessage(GetParent(hBn),WM_COMMAND,MAKEWPARAM(ButtonID,BN_CLICKED),(LPARAM)hBn);
		times=0;
		}
		break;
	   case WM_MOUSEMOVE:
		if(!Draw)
		{
		//Sleep(200);
        ShowBitmap(hDc,CHover,IDHover);
        if(strlen(lpWindowName)){
        if(hFont)SelectObject(hDc,hFont);
		SetTextColor(hDc,TextCol);
		SetBkMode(hDc,TRANSPARENT);
		DrawText(hDc,lpWindowName,strlen(lpWindowName),&rc,DT_CENTER|DT_SINGLELINE|DT_VCENTER);
		}
		IDPAINT=IDHover;
        CPaint=CHover;
		Draw=1;
		}
        TRACKMOUSEEVENT trmouse; 
        trmouse.cbSize = sizeof(TRACKMOUSEEVENT); 
        trmouse.dwFlags = TME_LEAVE | TME_HOVER ;
        trmouse.dwHoverTime = 200; 
     	trmouse.hwndTrack =hBn;  
        if(!_TrackMouseEvent(&trmouse))return FALSE;   
        break; 
		case WM_KEYDOWN:
         SendMessage(hParent,WM_KEYDOWN,wParam,0);
		break;
        default: 
		return CallWindowProc(OldProc,hBn,uMsgBn,wParam,lParam);  
        break; 
	 }
	ReleaseDC(hBn,hDc);
       return 1;
}