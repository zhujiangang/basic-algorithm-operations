
#if !defined(AFX__H__75017DA0_F72E_4BA9_8FDF_31A4E4048356__INCLUDED_)
#define AFX__H__75017DA0_F72E_4BA9_8FDF_31A4E4048356__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX__H__75017DA0_F72E_4BA9_8FDF_31A4E4048356__INCLUDED_)
