// ShellTreeCtrl.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2000 by Paolo Messina
// (ppescher@yahoo.com)
//
// Free for non-commercial use.
// You may change the code to your needs,
// provided that credits to the original 
// author is given in the modified files.
//  
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ShellTreeCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShellTreeCtrl

CShellTreeCtrl::CShellTreeCtrl()
{
	m_bIncludeFiles = FALSE;
	m_pidlRoot = NULL;

	m_pDesktopFolder = NULL;
	SHGetDesktopFolder(&m_pDesktopFolder);

	m_pMalloc = NULL;
	SHGetMalloc(&m_pMalloc);
}

CShellTreeCtrl::~CShellTreeCtrl()
{
	if (m_pidlRoot != NULL)
		m_pMalloc->Free(m_pidlRoot);

	if (m_pMalloc != NULL)
		m_pMalloc->Release();

	if (m_pDesktopFolder != NULL)
		m_pDesktopFolder->Release();
}


BEGIN_MESSAGE_MAP(CShellTreeCtrl, CWaitingTreeCtrl)
	//{{AFX_MSG_MAP(CShellTreeCtrl)
	ON_NOTIFY_REFLECT(TVN_DELETEITEM, OnDeleteItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShellTreeCtrl message handlers

BOOL CShellTreeCtrl::PopulateItem(HTREEITEM hParent)
{
	LPITEMIDLIST pidlParent;
	BOOL ret = FALSE;

	// get parent pidl
	if (hParent == TVI_ROOT)
		pidlParent = m_pidlRoot;
	else
		pidlParent = (LPITEMIDLIST)GetItemData(hParent);

	// get parent shell folder
	IShellFolder* pParentFolder = NULL;
	m_pDesktopFolder->BindToObject(pidlParent,
		NULL, IID_IShellFolder, (LPVOID*)&pParentFolder);

	// no folder object
	if (pParentFolder == NULL)
		if (hParent == TVI_ROOT)	// root is desktop
		{
			pParentFolder = m_pDesktopFolder;
			m_pDesktopFolder->AddRef();
		}
		else
			return TRUE;	//  don't try anymore

	// enum child pidls
	IEnumIDList* pEnumIDList = NULL;
	if (NOERROR == pParentFolder->EnumObjects(*this, SHCONTF_FOLDERS
		| ((m_bIncludeFiles) ? SHCONTF_NONFOLDERS : 0), &pEnumIDList))
	{
		SetPopulationCount(0);

		LPITEMIDLIST pidl = NULL, pidlAbs;
		while (NOERROR == pEnumIDList->Next(1, &pidl, NULL))
		{
			// get an absolute pidl
			pidlAbs = ILCombine(pidlParent, pidl);
			// add item
			TVINSERTSTRUCT tvis;
			ZeroMemory(&tvis, sizeof(TVINSERTSTRUCT));
			tvis.hParent = hParent;
			tvis.hInsertAfter = TVI_LAST;
			tvis.item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE
				| TVIF_CHILDREN | TVIF_PARAM;
			tvis.item.lParam = (LPARAM)pidlAbs;
			// fill with text, icons and children
			ret = FillItem(tvis.item, pidlAbs, pParentFolder, pidl);
			
			InsertItem(&tvis);

			IncreasePopulation();

			// free enumerated object
			m_pMalloc->Free(pidl);
		}
		// free enum object
		pEnumIDList->Release();
	}

	// sort items
	TVSORTCB tvscb;
	tvscb.hParent = hParent;
	tvscb.lpfnCompare = CompareFunc;
	tvscb.lParam = (LPARAM)pParentFolder;
	SortChildrenCB(&tvscb);

	// free folder object
	pParentFolder->Release();

	SetPopulationCount(1,1);

	// do not check for children if parent is a removable media
	// just try (if it's a filesystem object, it has a path)
	if (!ret)
		return FALSE;

	TCHAR path[MAX_PATH];
	if (SHGetPathFromIDList(pidlParent, path))
	{			
		UINT type = GetDriveType(path);
		if (type != DRIVE_FIXED)
			return FALSE;
	}

	return TRUE;
}

void CShellTreeCtrl::PreSubclassWindow() 
{
	InitializeControl();

	CWaitingTreeCtrl::PreSubclassWindow();
}

void CShellTreeCtrl::InitializeControl()
{
    //Attach to the system image list
	LPITEMIDLIST pidl = NULL;
	SHGetSpecialFolderLocation(*this, CSIDL_DESKTOP, &pidl);
    
    SHFILEINFO sfi;
	ZeroMemory(&sfi, sizeof(SHFILEINFO));
	HIMAGELIST hSysImageList = (HIMAGELIST) SHGetFileInfo((LPCTSTR)pidl, 0,
		&sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SMALLICON);

	m_pMalloc->Free(pidl);
	
	TreeView_SetImageList(*this, hSysImageList, TVSIL_NORMAL);
}

void CShellTreeCtrl::RefreshShellRoot(LPCITEMIDLIST pidlRoot, BOOL bIncludeFiles)
{
	m_bIncludeFiles = bIncludeFiles;

	// store root
	m_pidlRoot = ILClone(pidlRoot);

	RefreshSubItems(TVI_ROOT);

	return;
}

LPITEMIDLIST CShellTreeCtrl::ILCombine(LPCITEMIDLIST pidl1, LPCITEMIDLIST pidl2)
{
	// Get the size of the resulting item identifier list
	int cb1 = ILGetLength(pidl1);
	int cb2 = ILGetLength(pidl2); 
	
	// Allocate a new item identifier list
	LPITEMIDLIST pidlNew = (LPITEMIDLIST)m_pMalloc->Alloc(cb1 + cb2 + sizeof(USHORT)); 
	if (pidlNew == NULL)
		return NULL;
	
	// Copy the first item identifier list 
	if (cb1 > 0)
		CopyMemory(pidlNew, pidl1, cb1 + sizeof(USHORT));

	// Copy the second item identifier list and terminating 0
	if (cb2 > 0)
		CopyMemory((((LPBYTE) pidlNew) + cb1), pidl2, cb2 + sizeof(USHORT));
	
	if (cb1 == 0 && cb2 == 0)
	{
		m_pMalloc->Free(pidlNew);
		return NULL;
	}

	return pidlNew;
}

int CShellTreeCtrl::ILGetLength(LPCITEMIDLIST pidl)
{
	if (pidl == NULL)
		return 0;

	// does not include terminating 0
	int length = 0, cb;
	
	do
	{
		cb = pidl->mkid.cb;
		pidl = (LPCITEMIDLIST)(((LPBYTE)pidl) + cb);
		length += cb;
	}
	while (cb != 0);

	return length;
}

LPCITEMIDLIST CShellTreeCtrl::ILGetNext(LPCITEMIDLIST pidl)
{
	if (pidl == NULL)
		return NULL;

	// Get the size of the specified item identifier. 
	int cb = pidl->mkid.cb; 
	
	// If the size is zero, it is the end of the list. 
	if (cb == 0) 
		return NULL; 
	
	// Add cb to pidl (casting to increment by bytes). 
	pidl = (LPCITEMIDLIST)(((LPBYTE)pidl) + cb); 
	
	// Return NULL if it is null-terminating, or a pidl otherwise. 
	return (pidl->mkid.cb == 0) ? NULL : pidl;
}

LPITEMIDLIST CShellTreeCtrl::ILCloneFirst(LPCITEMIDLIST pidl)
{
	if (pidl == NULL)
		return NULL;

	// Get the size of the specified item identifier. 
	int cb = pidl->mkid.cb; 
	
	// Allocate a new item identifier list. 
	LPITEMIDLIST pidlNew = (LPITEMIDLIST)m_pMalloc->Alloc(cb + sizeof(USHORT)); 
	if (pidlNew == NULL) 
		return NULL; 
	
	// Copy the specified item identifier. 
	CopyMemory(pidlNew, pidl, cb); 
	
	// Append a terminating zero. 
	*((USHORT *) (((LPBYTE) pidlNew) + cb)) = 0; 
	
	return pidlNew; 
}

int CALLBACK CShellTreeCtrl::CompareFunc(LPARAM lParam1,
		LPARAM lParam2, LPARAM lParamSort)
{
	HRESULT hr = ((IShellFolder*)lParamSort)->CompareIDs(0,
		ILGetLast((LPCITEMIDLIST)lParam1),
		ILGetLast((LPCITEMIDLIST)lParam2));
	if (FAILED(hr))
		return 0;	// error, don't sort
	
	short ret = (short)HRESULT_CODE(hr);
	if (ret < 0)
		return -1;
	if (ret > 0)
		return 1;
	return 0;
}

// return FALSE if on a remote or removable media, TRUE otherwise
BOOL CShellTreeCtrl::FillItem(TVITEM& item, LPCITEMIDLIST pidl,
		IShellFolder* pParentFolder, LPCITEMIDLIST pidlRel)
{
	static CString sName; // must survive to this function
	SHFILEINFO sfi;
	DWORD dwAttributes;

	if (item.mask & TVIF_TEXT)
	{
		// get display name
		STRRET str;
		str.uType = STRRET_WSTR;
		pParentFolder->GetDisplayNameOf(pidlRel, SHGDN_INFOLDER |
			SHGDN_INCLUDE_NONFILESYS, &str);

		switch (str.uType)
		{
		case STRRET_WSTR:
			sName = str.pOleStr;
			m_pMalloc->Free(str.pOleStr);
			break;
		case STRRET_CSTR:
			sName = str.cStr;
			break;
		case STRRET_OFFSET:
			sName = (char*)((LPBYTE)pidlRel+str.uOffset);
		}
		item.pszText = (LPTSTR)(LPCTSTR)sName;
	}

	if (item.mask & (TVIF_IMAGE | TVIF_SELECTEDIMAGE))
	{
		// get some attributes
		dwAttributes = SFGAO_FOLDER | SFGAO_LINK;
		pParentFolder->GetAttributesOf(1, &pidlRel, &dwAttributes);

		// get correct icon
		UINT uFlags = SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SMALLICON;
		if (dwAttributes & SFGAO_LINK)
			uFlags |= SHGFI_LINKOVERLAY;

		if (item.mask & TVIF_IMAGE)
		{
			ZeroMemory(&sfi, sizeof(SHFILEINFO));
			SHGetFileInfo((LPCTSTR)pidl, 0, &sfi, sizeof(SHFILEINFO), uFlags);
			item.iImage = sfi.iIcon;
		}
		if (item.mask & TVIF_SELECTEDIMAGE)
		{
			if (dwAttributes & SFGAO_FOLDER)
				uFlags |= SHGFI_OPENICON;

			ZeroMemory(&sfi, sizeof(SHFILEINFO));
			SHGetFileInfo((LPCTSTR)pidl, 0, &sfi, sizeof(SHFILEINFO), uFlags);
			item.iSelectedImage = sfi.iIcon;
		}
	}

	if (item.mask & TVIF_CHILDREN)
	{
		// get some attributes
		dwAttributes = SFGAO_FOLDER | SFGAO_REMOVABLE;
		pParentFolder->GetAttributesOf(1, &pidlRel, &dwAttributes);

		// get children
		item.cChildren = 0;
		if (dwAttributes & SFGAO_FOLDER)
		{
			if (m_bIncludeFiles)
				item.cChildren = 1;
			else if (dwAttributes & SFGAO_REMOVABLE)
				item.cChildren = 1;
			else
			{
				dwAttributes = SFGAO_HASSUBFOLDER;
				pParentFolder->GetAttributesOf(1, &pidlRel, &dwAttributes);

				item.cChildren = (dwAttributes & SFGAO_HASSUBFOLDER) ? 1 : 0;
			}
		}
	}

	// check if removable or remote media
	SHDESCRIPTIONID sdi;
	ZeroMemory(&sdi, sizeof(SHDESCRIPTIONID));
	if (SUCCEEDED(SHGetDataFromIDList(pParentFolder, pidlRel,
		SHGDFIL_DESCRIPTIONID, &sdi, sizeof(SHDESCRIPTIONID))))
	{
		switch (sdi.dwDescriptionId)
		{
		case SHDID_COMPUTER_REMOVABLE:
		case SHDID_COMPUTER_DRIVE35:
		case SHDID_COMPUTER_DRIVE525:
		case SHDID_COMPUTER_NETDRIVE:
		case SHDID_COMPUTER_CDROM:
		case SHDID_NET_DOMAIN:
		case SHDID_NET_SERVER:
		case SHDID_NET_SHARE:
		case SHDID_NET_RESTOFNET:
		case SHDID_NET_OTHER:
			return FALSE;
		}
	}

	return TRUE;
}

void CShellTreeCtrl::OnDeleteItem(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TVITEM& item = ((NMTREEVIEW*)pNMHDR)->itemOld;

	// free PIDL
	if (item.lParam != 0)
		m_pMalloc->Free((LPVOID)item.lParam);

	*pResult = 0;
}

LPCITEMIDLIST CShellTreeCtrl::GetItemIDList(HTREEITEM hItem)
{
	return (LPCITEMIDLIST)GetItemData(hItem);
}

LPCITEMIDLIST CShellTreeCtrl::ILGetLast(LPCITEMIDLIST pidl)
{
	LPCITEMIDLIST ret = pidl, tmp = ILGetNext(pidl);
	while (tmp != NULL)
	{
		ret = tmp;
		tmp = ILGetNext(tmp);
	}
	return ret;
}


