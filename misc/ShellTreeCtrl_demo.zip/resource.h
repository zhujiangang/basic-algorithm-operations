//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDC_BROWSE_FILES                3
#define IDC_SETROOT                     5
#define IDC_REFRESH2                    6
#define IDD_TEST_DIALOG                 101
#define IDD_TESTNETWORK_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDB_NETWORK_IMAGE_LIST          129
#define IDD_SHELL_DIALOG                132
#define IDD_DEMO_DIALOG                 133
#define IDR_HOURGLASS                   555
#define IDC_NETWORK                     1000
#define IDC_BUTTON_TEST                 1001
#define IDC_EDIT_PROVIDER               1002
#define IDC_EDIT_REMOTE                 1003
#define IDC_EDIT_LOCAL                  1004
#define IDC_EDIT_COMMENT                1005
#define IDC_STC_PROVIDER                1006
#define IDC_STC_REMOTE                  1007
#define IDC_STC_LOCAL                   1008
#define IDC_STC_COMMENT                 1009
#define IDC_ONLY_COMPUTERS              1010
#define IDC_SET_ROOT                    1011
#define IDC_SHELL_TREE                  1011
#define IDC_TEST_NETWORK                1012
#define IDC_TEST_SHELL                  1013
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777
#define ID_BUTTON32778                  32778
#define ID_BUTTON32779                  32779
#define ID_BUTTON32780                  32780
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782
#define ID_BUTTON32783                  32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
