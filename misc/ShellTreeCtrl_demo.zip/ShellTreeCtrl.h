#if !defined(AFX_SHELLTREECTRL_H__98BDBB7B_E2C3_4145_A5D5_693274C6B99B__INCLUDED_)
#define AFX_SHELLTREECTRL_H__98BDBB7B_E2C3_4145_A5D5_693274C6B99B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ShellTreeCtrl.h : header file
//
/////////////////////////////////////////////////////////////////////////////
//
// Copyright (C) 2000 by Paolo Messina
// (ppescher@yahoo.com)
//
// Free for non-commercial use.
// You may change the code to your needs,
// provided that credits to the original 
// author is given in the modified files.
//  
/////////////////////////////////////////////////////////////////////////////

#include "WaitingTreeCtrl.h"

#include <afxtempl.h>
#include <shlobj.h>

/////////////////////////////////////////////////////////////////////////////
// CShellTreeCtrl window

class CShellTreeCtrl : public CWaitingTreeCtrl
{
private:
	BOOL m_bIncludeFiles;
	LPITEMIDLIST m_pidlRoot;
	IMalloc* m_pMalloc;
	IShellFolder* m_pDesktopFolder;

	// manage PIDLs
	static int ILGetLength(LPCITEMIDLIST pidl);
	static LPCITEMIDLIST ILGetNext(LPCITEMIDLIST pidl);
	static LPCITEMIDLIST ILGetLast(LPCITEMIDLIST pidl);
	LPITEMIDLIST ILCombine(LPCITEMIDLIST pidl1, LPCITEMIDLIST pidl2);
	LPITEMIDLIST ILCloneFirst(LPCITEMIDLIST pidl);
	LPITEMIDLIST ILClone(LPCITEMIDLIST pidl)
	{
		return ILCombine(pidl, NULL);
	};
	// generic
	void InitializeControl();
	BOOL FillItem(TVITEM& item, LPCITEMIDLIST pidl,
		IShellFolder* pParentFolder, LPCITEMIDLIST pidlRel);
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2,
		LPARAM lParamSort);

// Construction
public:
	CShellTreeCtrl();
	virtual ~CShellTreeCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShellTreeCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void RefreshShellRoot(LPCITEMIDLIST pidlRoot, BOOL bIncludeFiles = FALSE);
	LPCITEMIDLIST GetItemIDList(HTREEITEM hItem);

	// Generated message map functions
protected:
	virtual BOOL PopulateItem(HTREEITEM hParent);
	//{{AFX_MSG(CShellTreeCtrl)
	afx_msg void OnDeleteItem(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHELLTREECTRL_H__98BDBB7B_E2C3_4145_A5D5_693274C6B99B__INCLUDED_)
