// TestShellDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Demo.h"
#include "TestShellDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestShellDlg dialog


CTestShellDlg::CTestShellDlg(CWnd* pParent /*=NULL*/)
	: CResizableDialog(CTestShellDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestShellDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}


void CTestShellDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizableDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestShellDlg)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_SHELL_TREE, m_ctlShell);
}


BEGIN_MESSAGE_MAP(CTestShellDlg, CResizableDialog)
	//{{AFX_MSG_MAP(CTestShellDlg)
	ON_BN_CLICKED(IDC_SETROOT, OnSetRoot)
	ON_BN_CLICKED(IDC_BROWSE_FILES, OnBrowseFiles)
	ON_BN_CLICKED(IDC_REFRESH2, OnRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestShellDlg message handlers

BOOL CTestShellDlg::OnInitDialog() 
{
	CResizableDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// layout
	AddAnchor(IDC_SHELL_TREE, TOP_LEFT, BOTTOM_RIGHT);
	AddAnchor(IDC_BROWSE_FILES, BOTTOM_LEFT);
	AddAnchor(IDC_SETROOT, TOP_RIGHT);
	AddAnchor(IDC_REFRESH2, TOP_RIGHT);
	AddAnchor(IDOK, BOTTOM_RIGHT);

	// show the window
	CenterWindow();
	ShowWindow(SW_SHOW);
	UpdateWindow();

	// set title for error dialog boxes
	m_ctlShell.SetWindowText(_T("ShellTree Control"));

	// populate root
	m_ctlShell.RefreshShellRoot(NULL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTestShellDlg::OnSetRoot() 
{
	LPCITEMIDLIST pidl = m_ctlShell.GetItemIDList(m_ctlShell.GetSelectedItem());
	m_ctlShell.RefreshShellRoot(pidl, FALSE);
}

void CTestShellDlg::OnBrowseFiles() 
{
	m_ctlShell.RefreshShellRoot(NULL, TRUE);
}

void CTestShellDlg::OnRefresh() 
{
	HTREEITEM hParent = m_ctlShell.GetParentItem(m_ctlShell.GetSelectedItem());
	if (hParent == NULL)
		hParent = TVI_ROOT;
	m_ctlShell.RefreshSubItems(hParent);
}
